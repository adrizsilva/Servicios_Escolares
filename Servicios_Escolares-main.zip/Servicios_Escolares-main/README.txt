CATALOGOS:

USUARIOS:
    Id: Username / Matricula
    Pass: password -> pendiente cifrar la contraseña
    Type: Tipo de usuario -> 0: alumno   1: usuario
    Privileges:  Privilegios de acceso ->  0: alumno   1: Docente   2: Titulares   3: Coordinador/Director   4: Pendiente    5: Administrador
    
